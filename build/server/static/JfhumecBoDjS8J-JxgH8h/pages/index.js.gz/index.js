module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 3);
/******/ })
/************************************************************************/
/******/ ({

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__("MKDn");
module.exports = __webpack_require__("cMU6");


/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "Exp3":
/***/ (function(module, exports) {

module.exports = require("antd");

/***/ }),

/***/ "KiuA":
/***/ (function(module, exports) {

module.exports = require("dayjs/locale/zh-cn");

/***/ }),

/***/ "MKDn":
/***/ (function(module, exports) {

module.exports = require("D:\\Proyectos\\Personal\\Github\\curriculum-vitae\\node_modules\\antd-dayjs-webpack-plugin\\src\\init-dayjs.js");

/***/ }),

/***/ "boVf":
/***/ (function(module, exports) {

module.exports = require("dayjs");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cMU6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__("Exp3");

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__("xnum");
var head_default = /*#__PURE__*/__webpack_require__.n(head_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");

// EXTERNAL MODULE: external "dayjs"
var external_dayjs_ = __webpack_require__("boVf");
var external_dayjs_default = /*#__PURE__*/__webpack_require__.n(external_dayjs_);

// EXTERNAL MODULE: external "dayjs/locale/zh-cn"
var zh_cn_ = __webpack_require__("KiuA");

// CONCATENATED MODULE: ./utils/date-format.jsx


external_dayjs_default.a.locale('es');
const dateTime = date => external_dayjs_default()(date).locale('es').format();
const date_format_full = full => external_dayjs_default()(full).format('YYYY-MM-DD HH:mm:ss');
// EXTERNAL MODULE: external "title"
var external_title_ = __webpack_require__("uMCA");
var external_title_default = /*#__PURE__*/__webpack_require__.n(external_title_);

// CONCATENATED MODULE: ./utils/title-style.jsx

/* harmony default export */ var title_style = (text => external_title_default()(text, {
  special: ['insumos', 'productos', 'cumbre', 'sullana', 'piura', 'pasteles', 'tortas', 'cremas']
}));
// CONCATENATED MODULE: ./layouts/page.jsx
var __jsx = external_react_default.a.createElement;






const Page = ({
  children,
  date,
  description,
  image,
  title = 'Insumos cumbre',
  keywords,
  router
}) => {
  const domain = 'https://www.insumoscumbre.net/';
  const formattedTitle = title_style(title);
  return __jsx(external_react_default.a.Fragment, null, __jsx(head_default.a, null, __jsx("title", null, formattedTitle), __jsx("meta", {
    charSet: "utf-8"
  }), __jsx("meta", {
    content: "IE=edge",
    httpEquiv: "X-UA-Compatible"
  }), __jsx("meta", {
    content: "width=device-width, initial-scale=1",
    name: "viewport"
  }), description && __jsx("meta", {
    content: description,
    name: "description"
  }), keywords && __jsx("meta", {
    content: keywords,
    name: "keywords"
  }), __jsx("meta", {
    content: "follow, index",
    name: "robots"
  }), __jsx("meta", {
    content: "#ffffff",
    name: "theme-color"
  }), __jsx("meta", {
    content: "#ffffff",
    name: "msapplication-TileColor"
  }), __jsx("meta", {
    content: "/favicons/browserconfig.xml",
    name: "msapplication-config"
  }), __jsx("link", {
    href: "/favicons/apple-touch-icon.png",
    rel: "apple-touch-icon",
    sizes: "180x180"
  }), __jsx("link", {
    href: "/favicons/favicon-32x32.png",
    rel: "icon",
    sizes: "32x32",
    type: "image/png"
  }), __jsx("link", {
    href: "/favicons/favicon-16x16.png",
    rel: "icon",
    sizes: "16x16",
    type: "image/png"
  }), __jsx("link", {
    href: "/favicons/site.webmanifest",
    rel: "manifest"
  }), __jsx("link", {
    color: "#5bbad5",
    href: "/favicons/safari-pinned-tab.svg",
    rel: "mask-icon"
  }), __jsx("link", {
    href: "/favicons/favicon.ico",
    rel: "shortcut icon"
  }), __jsx("link", {
    rel: "stylesheet",
    href: "https://pro.fontawesome.com/releases/v5.8.2/css/all.css",
    integrity: "sha384-xVVam1KS4+Qt2OrFa+VdRUoXygyKIuNWUUUBZYv+n27STsJ7oDOHJgfF0bNKLMJF",
    crossOrigin: "anonymous"
  }), __jsx("meta", {
    content: "es_PE",
    property: "og:locale"
  }), __jsx("meta", {
    content: formattedTitle,
    property: "og:title"
  }), __jsx("meta", {
    content: description,
    property: "og:description"
  }), date && __jsx(external_react_default.a.Fragment, null, __jsx("meta", {
    content: "article",
    property: "og:type"
  }), __jsx("meta", {
    content: dateTime(date),
    property: "article:published_time"
  }))), children);
};

/* harmony default export */ var page = (Object(router_["withRouter"])(Page));
// CONCATENATED MODULE: ./pages/index.jsx
var pages_jsx = external_react_default.a.createElement;



const {
  Meta
} = external_antd_["Card"];

const Index = props => {
  const {
    userAgent
  } = props;
  console.log(userAgent);
  return pages_jsx(external_react_default.a.Fragment, null, pages_jsx(page, {
    description: 'Curriculum Vitae',
    image: '/images/logo/logo.png',
    title: 'Curriculum Vitae'
  }, pages_jsx("main", null, pages_jsx(external_antd_["Layout"], {
    className: "layout"
  }, pages_jsx(external_antd_["Row"], {
    type: "flex",
    justify: "center"
  }, pages_jsx(external_antd_["Col"], {
    className: "content",
    xs: 24,
    sm: 24,
    md: 20,
    lg: 20,
    xl: 10
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    xs: 24,
    sm: 24,
    md: 24,
    lg: 9,
    xl: 9,
    className: "column-info"
  }, pages_jsx("div", {
    className: "title"
  }, pages_jsx("div", null, pages_jsx("img", {
    className: "profile-photo",
    alt: "profile-photo",
    src: "/photo.jpg"
  })), pages_jsx("div", {
    className: "details-space"
  }, pages_jsx("span", null, "Peruano de 26 A\xF1os, nacido en Sullana")), pages_jsx("div", {
    className: "details-space"
  }, pages_jsx(external_antd_["Row"], null, pages_jsx("a", {
    href: "https://wa.me/51991030952?text=Interesado%20curriculum",
    target: "_top"
  }, pages_jsx(external_antd_["Space"], {
    size: 13
  }, pages_jsx("div", null, pages_jsx("i", {
    className: "fab fa-whatsapp"
  }), pages_jsx("i", {
    className: "fal fa-phone-volume"
  })), pages_jsx("div", null, "991030952")))), pages_jsx(external_antd_["Row"], null, pages_jsx("a", {
    href: "https://wa.me/51918558986?text=Interesado%20curriculum",
    target: "_top"
  }, pages_jsx(external_antd_["Space"], {
    size: 13
  }, pages_jsx("div", null, pages_jsx("i", {
    className: "fal fa-phone-volume"
  })), pages_jsx("div", null, "918558986")))), pages_jsx(external_antd_["Row"], null, pages_jsx("a", {
    href: "mailto:hugo.93wal@gmail.com?Subject=Interesado%20curriculum",
    target: "_top"
  }, pages_jsx(external_antd_["Space"], {
    size: 13
  }, pages_jsx("i", {
    className: "fal fa-envelope"
  }), pages_jsx("div", null, "hugo.93wal@gmail.com")))), pages_jsx(external_antd_["Row"], null, pages_jsx("a", {
    href: "mailto:mailto:hugo.93wal@protonmail.com?Subject=Interesado%20curriculum",
    target: "_top"
  }, pages_jsx(external_antd_["Space"], {
    size: 13
  }, pages_jsx("i", {
    className: "fal fa-envelope"
  }), pages_jsx("div", null, "hugo.93wal@protonmail.com"))))), pages_jsx("div", {
    className: "details-space"
  }, pages_jsx(external_antd_["Row"], null, pages_jsx("a", {
    href: "https://github.com/wsantin",
    target: "_top"
  }, pages_jsx(external_antd_["Space"], {
    size: 13
  }, pages_jsx("i", {
    className: "fab fa-github"
  }), pages_jsx("div", null, "github.com/wsantin")))), pages_jsx(external_antd_["Row"], null, pages_jsx("a", {
    href: "https://www.facebook.com/WHsantin",
    target: "_top"
  }, pages_jsx(external_antd_["Space"], {
    size: 13
  }, pages_jsx("i", {
    className: "fab fa-facebook-f"
  }), pages_jsx("div", null, "facebook.com/WHsantin"))))), pages_jsx("div", {
    className: "details-space"
  }, pages_jsx(external_antd_["Row"], {
    className: "sub-title"
  }, "Actividades"), pages_jsx(external_antd_["Row"], null, pages_jsx("ul", null, pages_jsx("li", null, "Sistemas en la nube"), pages_jsx("li", null, "Arquitectura de Sistemas"), pages_jsx("li", null, "Aplicaciones Web"), pages_jsx("li", null, "Frontend Y Backend"), pages_jsx("li", null, "Pentesting"), pages_jsx("li", null, "Hacking \xC9tico"), pages_jsx("li", null, "Trabajo en equipo")))), pages_jsx("div", {
    className: "details-space"
  }, pages_jsx(external_antd_["Row"], {
    className: "sub-title"
  }, "Formaci\xF3n"), pages_jsx(external_antd_["Row"], {
    className: "sub-title-content"
  }, pages_jsx("strong", null, "Ing. Inform\xE1tica"), pages_jsx("span", null, "Universidad nacional de Piura"))), pages_jsx("div", {
    className: "details-space"
  }, pages_jsx(external_antd_["Row"], {
    className: "sub-title"
  }, "Intereses"), pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Row"], {
    gutter: [14, 24],
    className: "sub-title-content"
  }, pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx("i", {
    className: "fal fa-futbol fa-2x"
  })), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx("i", {
    className: "fas fa-camera fa-2x"
  })), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx("i", {
    className: "far fa-plane fa-2x"
  })), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx("i", {
    className: "fal fa-cloud-sun fa-2x"
  })), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx("i", {
    className: "far fa-laptop fa-2x"
  })), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx("i", {
    className: "fal fa-headphones fa-2x"
  })), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx("i", {
    className: "fas fa-books fa-2x"
  })), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx("i", {
    className: "far fa-gamepad fa-2x"
  }))))))), pages_jsx(external_antd_["Col"], {
    xs: 24,
    sm: 24,
    md: 24,
    lg: 15,
    xl: 15,
    className: "column-description"
  }, pages_jsx("div", {
    className: "context"
  }, pages_jsx("div", {
    className: "title"
  }, pages_jsx("h1", null, "WALTER HUGO SANTIN ZAPATA"), pages_jsx("div", {
    className: "title-fin"
  }, "Desarrollador Software"), pages_jsx("div", {
    className: "title-fin"
  }, "Pentester - Hacking \xC9tico")), pages_jsx("div", {
    className: "sub-title"
  }, "Autodescripci\xF3n"), pages_jsx("div", {
    className: "description"
  }, "Me apasiona la tecnolog\xEDa, desarrollandome eficientemente con muchas ganas de superaci\xF3n, con nivel de responsabilidad para tareas y trabajo en equipo. Soy programador Fullstack y Analista en busca de Fallos de seguridad en nivel de servidor, servicios y aplicaciones Web."), pages_jsx("div", {
    className: "sub-title"
  }, "Competencias"), pages_jsx("div", {
    className: "sub-title-content"
  }, pages_jsx("ul", null, pages_jsx("li", null, "Comunicaci\xF3n"), pages_jsx("li", null, "Flexibilidad"), pages_jsx("li", null, "Especialista en Frontend y backend"), pages_jsx("li", null, "Protecci\xF3n de hackers Black"), pages_jsx("li", null, "Constante inter\xE9s en seguir aprendiendo"), pages_jsx("li", null, "Hacer bien las cosas"), pages_jsx("li", null, "Ordenado, Puntual y responsable"))), pages_jsx("div", {
    className: "sub-title"
  }, "Experiencias Profesionales"), pages_jsx("div", {
    className: "sub-title-content"
  }, pages_jsx(external_antd_["Timeline"], {
    mode: "left"
  }, pages_jsx(external_antd_["Timeline"].Item, {
    label: "2020",
    className: "time-line-item",
    color: "#3D7C6E"
  }, pages_jsx("div", null, pages_jsx("strong", null, "Agros tech: "), pages_jsx("span", null, "Desarrollador Fullstack. Tiempo: Actual"))), pages_jsx(external_antd_["Timeline"].Item, {
    label: "2019",
    className: "time-line-item",
    color: "gray"
  }, pages_jsx("div", null, pages_jsx("strong", null, "Nytec Sac: "), pages_jsx("span", null, "Analista y desarrollador Web. Soporte en Telef\xF3nica. Tiempo: 6 Meses"))), pages_jsx(external_antd_["Timeline"].Item, {
    label: "2017",
    className: "time-line-item",
    color: "gray"
  }, pages_jsx("div", null, pages_jsx("strong", null, "Gobierno Regional de Piura: "), pages_jsx("span", null, "Analista en seguridad de Informaci\xF3n. Desarrollador Aplicaciones Web. Tiempo: 1 A\xF1o"))), pages_jsx(external_antd_["Timeline"].Item, {
    label: "2014",
    className: "time-line-item",
    color: "gray"
  }, pages_jsx("div", null, pages_jsx("strong", null, "Infonet Soluciones Eirl: "), pages_jsx("span", null, "Analista de seguridad en Aplicaciones Web y servidores. Charlas Conferencias. Tiempo: 8 Meses"))), pages_jsx(external_antd_["Timeline"].Item, {
    label: "2014",
    className: "time-line-item",
    color: "gray"
  }, pages_jsx("div", null, pages_jsx("strong", null, "Walter Omar Tecnolog\xEDa: "), pages_jsx("span", null, "T\xE9cnico de computadoras, ensamblaje y reparaci\xF3n. Tiempo: 2 A\xF1os")))))), pages_jsx("div", {
    className: "experence"
  }, pages_jsx("div", {
    className: "sub-title"
  }, "Habilidades"), pages_jsx("div", {
    className: "sub-title-content"
  }, pages_jsx(external_antd_["Row"], {
    gutter: 24,
    style: {
      fontSize: '0.7rem'
    }
  }, pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "Php")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 60,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "Angular")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 50,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "React")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 80,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "Rest")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 80,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "Node js")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 90,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "SQL")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 60,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "NoSql")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 60,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "React Native")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 50,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "Cms")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 60,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "Js/Es6")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 80,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "Typescript")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 70,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "Testing")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 70,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "Preprocesadores")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 80,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "Photoshop")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 80,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "UX/UI")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 70,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "Git")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 80,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "Linux Windows")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 70,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "Docker")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 60,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "Owasp Security")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 90,
    showInfo: false
  })))), pages_jsx(external_antd_["Col"], {
    className: "gutter-row",
    span: 6
  }, pages_jsx(external_antd_["Row"], null, pages_jsx(external_antd_["Col"], {
    span: 15,
    className: "habilidades-item"
  }, pages_jsx("strong", null, "Pentesting Ofensive")), pages_jsx(external_antd_["Col"], {
    span: 9
  }, pages_jsx(external_antd_["Progress"], {
    percent: 90,
    showInfo: false
  })))))))))))))));
};

/* harmony default export */ var pages = __webpack_exports__["default"] = (Index);

/***/ }),

/***/ "uMCA":
/***/ (function(module, exports) {

module.exports = require("title");

/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ })

/******/ });